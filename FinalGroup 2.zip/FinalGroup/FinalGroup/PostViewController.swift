//
//  PostViewController.swift
//  FinalGroup
//
//  Created by ConnerRaby on 12/13/16.
//  Copyright © 2016 ConnerRaby. All rights reserved.
//

import UIKit

class PostViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    import Alamofire
    import UIKit
    
    class PostViewController: UIViewController {
        
        @IBOutlet weak var txtSubject: UITextField!
        @IBOutlet weak var txtDescription: UITextField!
        @IBOutlet weak var btnSend: UIButton!
        @IBOutlet weak var lblError: UILabel!
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            lblError.text = "";
        }
        
        @IBAction func btnSend_Tap(_ sender: UIButton) {
            let url = "http://localhost:3000/task"
            
            let params: Parameters = [
                "subject" : txtSubject.text!,
                "description" : txtDescription.text!
            ]
            
            Alamofire.request(url , method: .post, parameters: params, encoding: JSONEncoding.default).responseString { response in
                debugPrint(response)
            }
        }
    }

}
