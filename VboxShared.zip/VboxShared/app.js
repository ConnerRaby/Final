/*
* It's important to escape characters to avoid SQL injection 
* https://github.com/mysqljs/mysql#escaping-query-values
* 
* HTTP status codes
* https://en.wikipedia.org/wiki/List_of_HTTP_status_codes
*/ 

var http        = require('http');
var mysql       = require('mysql');
var express     = require('express');
var bodyParser  = require('body-parser');

var connection = mysql.createConnection({
   host : 'localhost',
   user : 'root',
   password : 'hawklet',
   database : 'finalgroup'
});

connection.connect();

connection.query('SELECT 1 + 1 AS solution', function(err, rows, fields) {
   if(err) throw err;
   else console.log('database connected');
});

// instance of express server
var app = express();

// makes it possible to parse JSON
app.use(bodyParser.json());

// middleware: ready to handle invalid json
app.use(function(error, req, res, next) {
   if (error instanceof SyntaxError) {
       res.status(400).send('Bad Request');
   } else {
       next();
   }
});

/* POST - CREATE */
app.post('/finalgroup', function(req, res) {
   console.log('/finalgroup req.body = ' + JSON.stringify(req.body));
   var insert = 'INSERT INTO finalgroup SET ?';
   connection.query(insert, req.body, function(err, rows) {
       if(err) {
           res.status(400).send('Bad Request');
       } else {
           res.status(201).send('Created');
       }
   });
});

/* GET - READ */
app.get('/finalgroup', function(req, res) {
   var select = 'SELECT * FROM tasks';
   connection.query(select, function(err, rows) {
       res.send({ data : rows });
   });
});

app.get('/finalgroup/:id', function(req, res) {
   var select = 'SELECT * FROM tasks WHERE task_id = ?';
   connection.query(select, [req.params.id], function(err, rows) {
       res.send({ data : rows });
   });
});

/* PUT - UPDATE */
app.put('/finalgroup/:id', function(req, res) {
   console.log('put finalgroup with id: ' + req.params.id);
});

/* DELETE */
app.delete('/finalgroup/:id', function(req, res) {
   console.log('delete finalgroup with id: ' + req.params.id);
});

http.createServer(app).listen(3000);

console.log('http://localhost:3000/');